import 'package:flutter/material.dart';
import 'package:estadogeneradoraapp/src/app.dart';

void main() => runApp(MyApp());
